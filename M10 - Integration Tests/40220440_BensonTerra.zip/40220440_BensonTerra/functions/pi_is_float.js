function pi_is_float() {
    console.log("pi_is_float")
    return Math.PI
}

module.exports = pi_is_float;