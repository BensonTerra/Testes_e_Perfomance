const users = [
  {id: 1, name: "Carlos", email: "carlos@email.com", password: "12345", nationality: "None"},
  {id: 2, name: "Maria", email: "maria@email.com", password: "54321", nationality: "Brazil"},
  {id: 3, name: "John", email: "john@email.com", password: "abcde", nationality: "USA"},
  {id: 4, name: "Sophie", email: "sophie@email.com", password: "qwerty", nationality: "France"},
  {id: 5, name: "Li", email: "li@email.com", password: "asdfg", nationality: "China"},
  {id: 6, name: "Anna", email: "anna@email.com", password: "zxcvb", nationality: "Italy"},
  {id: 7, name: "Igor", email: "igor@email.com", password: "poiuy", nationality: "Russia"},
  {id: 8, name: "Akira", email: "akira@email.com", password: "mnbvc", nationality: "Japan"},
  {id: 9, name: "Luiz", email: "luiz@email.com", password: "lkjhg", nationality: "Brazil"},
  {id: 10, name: "Mia", email: "mia@email.com", password: "hgfds", nationality: "Italy"}
];

//Data will go here
module.exports = users;  