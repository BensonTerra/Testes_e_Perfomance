for (let index = 0; index < 100000; index++) {
   console.log("Doing Nothing");
}