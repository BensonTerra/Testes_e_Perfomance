# TSIW - Tecnologias e Sistemas de Informação para a Web

Exemplos da Framework de testes JEST para a realização de testes unitários em NodeJS. Aplicação demonstrativa para a unidade curricular de Testes e Performance Web do 2º Ano da Licenciatura em Tecnologias e Sistemas de Informação para a Web da ESMAD - IPP. 

## Requesitos: 
 - NodeJS; 

## Instalação 

```sh
$ git clone https://github.com/joaoadrianoferreira/ESMAD-TSIW-M09-JEST.git
$ cd ESMAD-TSIW-M09-JEST
$ npm install
$ npm test
```

## Autor
João Ferreira
